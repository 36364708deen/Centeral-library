#include <stdio.h>
#include <stdlib.h>
#include <string.h>

FILE *btr = NULL;
struct Quantum
{
    char books[1000][90];
    int no_of_books;
} c;

void Available()
{
    char con;
    btr = fopen("Central Libaray.txt", "r");
    if (btr == NULL)
    {
        printf("File is not exit.");
    }
    while (!feof(btr))
    {
        con = fgetc(btr);
        printf("%c", con);
    }
    fclose(btr);
}
void main()
{
    int ch;
    char name[50];
    while (1)
    {
        system("cls");
        printf("\t\t\t\t\t=========== Welcome To Qunatum Library ===========\t\t\n\n");
        printf("\t\t\tPress [1] For available Books.\n");
        printf("\t\t\tPress [2] For Add Books.\n");
        printf("\t\t\tPress [3] For Creating Numbers Of Files For Library.\n");
        printf("\t\t\tPress [0] For Exit.\n");
        scanf("%d", &ch);
        switch (ch)
        {
        case 1:
            int s1;
            system("cls");
            printf("Available Books are : \n");
            Available();
            printf("\nPress [0] For Exit.\n");
            scanf("%d", &s1);
            if (s1 == 0)
                break;

        case 2:
            int s2;
            while (1)
            {
                system("cls");
                printf("Enter your name : ");
                fflush(stdin);
                gets(name);
                printf("Enter number of books , you want to add in library : ");
                scanf("%d", &c.no_of_books);
                btr = fopen("Central Libaray.txt", "a");
                fprintf(btr, "\nDate is %s\n", __DATE__);
                fprintf(btr, "Time is %s\n", __TIME__);
                fprintf(btr, "Librarian name is %s\n", name);
                for (int i = 0; i < c.no_of_books; i++)
                {
                    printf("Enter the name of book : ");
                    fflush(stdin);
                    gets(c.books[0]);
                    fprintf(btr, "Book name is %s\n", c.books);
                }
                printf("Book have been added in the library.\n");
                printf("Press [1] For continue and [0] For exit : \n");
                scanf("%d", &s2);
                fclose(btr);
                if (s2 == 0)
                    break;
            }
            break;
        case 3:
            system("cls");
            FILE *ptr = NULL;
            int filno, s3;
            char content[1000];
            while (1)
            {
                fflush(stdin);
                printf("How many files you want to create : ");
                scanf("%d", &filno);
                for (int i = 0; i < filno; i++)
                {
                    printf("Enter the file name : ");
                    fflush(stdin);
                    gets(name);
                    ptr = fopen(name, "a");
                    fprintf(ptr, "Name is %s\n\n", name);
                    printf("Enter the content : ");
                    fflush(stdin);
                    gets(content);
                    fprintf(ptr, "Content is : \n\t%s", content);
                }
                fclose(ptr);
                printf("Press [1] For continue [0] For Exit : ");
                scanf("%d", &s3);
                if (s3 == 0)
                    break;
            }
            break;
        }
        if (ch == 0)
            break;
    }
}
